--
-- PostgreSQL database dump
--

\restrict MZVRvgNia84EXPGIwL8lV4RvypAh5DOA3MVveHDzfp5RffIXrntRg2KHuZO3Bf7

-- Dumped from database version 15.15 (Debian 15.15-1.pgdg12+1)
-- Dumped by pg_dump version 15.15 (Debian 15.15-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: admin
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO admin;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: admin
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Appointment; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Appointment" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Appointment" OWNER TO admin;

--
-- Name: MedicalExam; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."MedicalExam" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "centerName" text NOT NULL,
    "doctorName" text NOT NULL,
    "examDate" timestamp(3) without time zone NOT NULL,
    "fileUrl" text NOT NULL,
    "fileName" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    source text DEFAULT 'portal interno'::text NOT NULL,
    "uploadedByUserId" text,
    reviewed boolean DEFAULT false NOT NULL
);


ALTER TABLE public."MedicalExam" OWNER TO admin;

--
-- Name: MedicalKnowledge; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."MedicalKnowledge" (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    category text,
    "imageUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."MedicalKnowledge" OWNER TO admin;

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    "patientId" text NOT NULL,
    "examId" text,
    read boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Notification" OWNER TO admin;

--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    email text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PasswordResetToken" OWNER TO admin;

--
-- Name: Patient; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Patient" (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    rut text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    phone text,
    commune text NOT NULL,
    region text,
    gender text,
    address text,
    "birthDate" timestamp(3) without time zone,
    "healthSystem" text,
    cota double precision,
    "diagnosisDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Patient" OWNER TO admin;

--
-- Name: PulmonaryFunctionTest; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PulmonaryFunctionTest" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "cvfValue" double precision,
    "cvfPercent" integer,
    "vef1Value" double precision,
    "vef1Percent" integer,
    "dlcoPercent" integer,
    "walkDistance" double precision,
    "spo2Rest" integer,
    "spo2Final" integer,
    "heartRateRest" integer,
    "heartRateFinal" integer,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PulmonaryFunctionTest" OWNER TO admin;

--
-- Name: RolePermission; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."RolePermission" (
    id text NOT NULL,
    role text NOT NULL,
    action text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."RolePermission" OWNER TO admin;

--
-- Name: SystemLog; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SystemLog" (
    id text NOT NULL,
    action text NOT NULL,
    details text,
    "userId" text,
    "userEmail" text,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."SystemLog" OWNER TO admin;

--
-- Name: User; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    rut text,
    password text NOT NULL,
    name text,
    role text DEFAULT 'KINESIOLOGIST'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "mustChangePassword" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO admin;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO admin;

--
-- Data for Name: Appointment; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Appointment" (id, "patientId", date, status, notes, "createdAt", "updatedAt") FROM stdin;
cmkg66sid0035zvodt9jqpwde	cmkg66l5y0033zvod31ebkqah	2026-02-15 12:00:00	PENDING	Reserva Web	2026-01-16 00:58:30.227	2026-01-16 00:58:30.227
cmkg6weq9003rzvodgrhxaszt	cmkg6wbbz003pzvodlso90ivh	2026-02-15 12:00:00	PENDING	Reserva Web	2026-01-16 01:18:25.425	2026-01-16 01:18:25.425
cmkg7fc5j004vzvodel2tnuqw	cmkg7ew5d004rzvodobjdmir1	2026-02-15 12:00:00	PENDING	Reserva Web	2026-01-16 01:33:08.551	2026-01-16 01:33:08.551
cmklvvf4700087890tklt9edw	cmklvv9nk00067890unufkvst	2026-02-15 12:00:00	PENDING	Reserva Web	2026-01-20 00:56:20.552	2026-01-20 00:56:20.552
cmklvz814000n7890l7mcmni6	cmklvz5ff000l7890uephpek7	2026-02-15 12:00:00	PENDING	Reserva Web	2026-01-20 00:59:17.992	2026-01-20 00:59:17.992
cmklw28d700117890impytqr9	cmklw26cp000z7890s5c161f1	2026-02-15 12:00:00	PENDING	Reserva Web	2026-01-20 01:01:38.395	2026-01-20 01:01:38.395
\.


--
-- Data for Name: MedicalExam; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."MedicalExam" (id, "patientId", "centerName", "doctorName", "examDate", "fileUrl", "fileName", "createdAt", "updatedAt", source, "uploadedByUserId", reviewed) FROM stdin;
cmkg6pdy5003bzvod00zxbev3	cmkg6pcbe0039zvod4l8b9a9u	Clínica Test E2E	Dr. Playwright	2025-01-01 00:00:00	http://localhost:3000/api/mock-storage/1768525977818-dummy.pdf	dummy.pdf	2026-01-16 01:12:57.821	2026-01-16 01:12:57.821	portal interno	\N	f
cmkg70p480040zvodl6mdwi4m	cmkg70law003yzvodrp6k3hw8	Clínica Test E2E	Dr. Playwright	2025-01-01 00:00:00	http://localhost:3000/api/mock-storage/1768526505504-dummy.pdf	dummy.pdf	2026-01-16 01:21:45.508	2026-01-16 01:21:45.508	portal interno	\N	f
cmklyyis2000378xwetffibvy	cmklyyf1t000078xwrlrr3dht	Clínica Test E2E	Dr. Playwright	2025-01-01 00:00:00	http://localhost:3000/api/mock-storage/1768875764111-dummy.pdf	dummy.pdf	2026-01-20 02:22:44.114	2026-01-20 02:22:44.114	portal interno	\N	f
cmklyyjnw000678xwqujcncwu	cmklyyg54000178xwm1ijt0wh	Clínica Test E2E	Dr. Playwright	2025-01-01 00:00:00	http://localhost:3000/api/mock-storage/1768875765259-dummy.pdf	dummy.pdf	2026-01-20 02:22:45.26	2026-01-20 02:22:45.26	portal interno	\N	f
cmklyylu0000878xw7jx2ouev	cmklyyjnk000478xwve8rb4fc	Clínica Test E2E	Dr. Playwright	2025-01-01 00:00:00	http://localhost:3000/api/mock-storage/1768875768071-dummy.pdf	dummy.pdf	2026-01-20 02:22:48.072	2026-01-20 02:22:48.072	portal interno	\N	f
cmklyyn53000b78xwi2gv43uh	cmklyymm2000978xwpvziccfv	Clínica Test E2E	Dr. Playwright	2025-01-01 00:00:00	http://localhost:3000/api/mock-storage/1768875769766-dummy.pdf	dummy.pdf	2026-01-20 02:22:49.767	2026-01-20 02:22:49.767	portal interno	\N	f
\.


--
-- Data for Name: MedicalKnowledge; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."MedicalKnowledge" (id, title, content, category, "imageUrl", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Notification" (id, type, title, message, "patientId", "examId", read, "createdAt") FROM stdin;
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."PasswordResetToken" (id, email, token, expires, "createdAt") FROM stdin;
\.


--
-- Data for Name: Patient; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Patient" (id, email, password, name, rut, active, phone, commune, region, gender, address, "birthDate", "healthSystem", cota, "diagnosisDate", "createdAt", "updatedAt") FROM stdin;
cmkg5pjog002ozvod1fvkdhvf	iphone_login_1768524304819@test.com	$2b$10$pD6WoqPeymdbHFUuokJW8.ASWg78GGUkeI4f3IDVXrWDcIW8K/2c6	iPhone Test User	18.655.736-0	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:45:05.632	2026-01-16 00:45:05.632
cmkg5ppss002pzvodmy56ah2u	ipad_login_1768524312198@test.com	$2b$10$zJ/dfcMk/fAPiwgyRTCeaOx7.NlnHYr8inVZP1EXaksoJXlkmU.hy	iPad Test User	16.895.876-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:45:13.564	2026-01-16 00:45:13.564
cmkg60uor000313oywo8wror8	paciente3@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Camila Perez Munoz	10000002-2	t	\N	MACUL	\N	Otro	Calle 3 # 718, MACUL	1955-11-03 04:00:00	\N	\N	2026-01-16 00:53:53.115	2026-01-16 00:53:53.115	2026-01-20 01:01:34.255
cmkg60uot000413oytaimu1fc	paciente4@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Pedro Perez Espinoza	10000003-3	t	\N	RECOLETA	\N	Otro	Calle 4 # 104, RECOLETA	1953-08-04 04:00:00	\N	\N	2026-01-16 00:53:53.116	2026-01-16 00:53:53.117	2026-01-20 01:01:34.257
cmkg60uou000513oysp1d3flx	paciente5@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Carolina Araya Torres	10000004-4	t	\N	LAS CONDES	\N	Otro	Calle 5 # 630, LAS CONDES	1968-04-27 04:00:00	\N	\N	2026-01-16 00:53:53.118	2026-01-16 00:53:53.118	2026-01-20 01:01:34.258
cmkg60uow000613oy5nw1fovu	paciente6@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Pedro Flores Rojas	10000005-5	t	\N	RECOLETA	\N	Masculino	Calle 6 # 154, RECOLETA	1999-01-15 03:00:00	\N	\N	2026-01-16 00:53:53.119	2026-01-16 00:53:53.12	2026-01-20 01:01:34.259
cmkg60uox000713oybra6ouz4	paciente7@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Francisca Flores Martinez	10000006-6	t	\N	LAS CONDES	\N	Otro	Calle 7 # 912, LAS CONDES	1987-07-22 04:00:00	\N	\N	2026-01-16 00:53:53.121	2026-01-16 00:53:53.122	2026-01-20 01:01:34.262
cmkg60uoy000813oy8ta9x0ub	paciente8@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Jorge Gonzalez Valenzuela	10000007-7	t	\N	MACUL	\N	Femenino	Calle 8 # 467, MACUL	1997-09-17 04:00:00	\N	\N	2026-01-16 00:53:53.122	2026-01-16 00:53:53.123	2026-01-20 01:01:34.263
cmkg60up0000913oy6of739ju	paciente9@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Maria Gonzalez Soto	10000008-8	t	\N	SANTIAGO	\N	Femenino	Calle 9 # 733, SANTIAGO	1967-09-08 04:00:00	\N	\N	2026-01-16 00:53:53.123	2026-01-16 00:53:53.124	2026-01-20 01:01:34.265
cmkg60up1000a13oyto2paocs	paciente10@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Constanza Fuentes Rojas	10000009-0	t	\N	LAS CONDES	\N	Femenino	Calle 10 # 21, LAS CONDES	1971-03-27 04:00:00	\N	\N	2026-01-16 00:53:53.125	2026-01-16 00:53:53.125	2026-01-20 01:01:34.266
cmkg60up3000b13oy5ckfj9xl	paciente11@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Francisca Fuentes Rojas	10000010-1	t	\N	QUILICURA	\N	Otro	Calle 11 # 2, QUILICURA	1976-11-28 03:00:00	\N	\N	2026-01-16 00:53:53.126	2026-01-16 00:53:53.127	2026-01-20 01:01:34.268
cmkg60up4000c13oy0wxb0ixn	paciente12@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Pedro Torres Perez	10000011-2	t	\N	VITACURA	\N	Masculino	Calle 12 # 858, VITACURA	1961-02-22 04:00:00	\N	\N	2026-01-16 00:53:53.128	2026-01-16 00:53:53.128	2026-01-20 01:01:34.269
cmkg60up5000d13oymrz8o9ag	paciente13@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Maria Lopez Hernandez	10000012-3	t	\N	LA CISTERNA	\N	Femenino	Calle 13 # 952, LA CISTERNA	1963-08-22 04:00:00	\N	\N	2026-01-16 00:53:53.129	2026-01-16 00:53:53.129	2026-01-20 01:01:34.27
cmkg60up8000f13oy1ugv2rbv	paciente15@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Francisca Gonzalez Morales	10000014-5	t	\N	PUENTE ALTO	\N	Otro	Calle 15 # 185, PUENTE ALTO	1955-05-04 04:00:00	\N	\N	2026-01-16 00:53:53.132	2026-01-16 00:53:53.132	2026-01-20 01:01:34.273
cmkg60upa000g13oy08ahvs62	paciente16@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Jorge Martinez Munoz	10000015-6	t	\N	MAIPU	\N	Masculino	Calle 16 # 451, MAIPU	1994-06-20 04:00:00	\N	\N	2026-01-16 00:53:53.134	2026-01-16 00:53:53.134	2026-01-20 01:01:34.274
cmkg60upc000h13oyuoz0z0ko	paciente17@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Carolina Gonzalez Araya	10000016-7	t	\N	PROVIDENCIA	\N	Femenino	Calle 17 # 843, PROVIDENCIA	1965-06-18 04:00:00	\N	\N	2026-01-16 00:53:53.136	2026-01-16 00:53:53.136	2026-01-20 01:01:34.276
cmkg60upd000i13oy1hoh8rn1	paciente18@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Camila Espinoza Martinez	10000017-8	t	\N	SANTIAGO	\N	Otro	Calle 18 # 514, SANTIAGO	1952-07-24 04:00:00	\N	\N	2026-01-16 00:53:53.137	2026-01-16 00:53:53.138	2026-01-20 01:01:34.277
cmkg60upe000j13oyr31h1hnj	paciente19@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Maria Fuentes Lopez	10000018-0	t	\N	PUENTE ALTO	\N	Otro	Calle 19 # 661, PUENTE ALTO	1983-10-26 03:00:00	\N	\N	2026-01-16 00:53:53.138	2026-01-16 00:53:53.139	2026-01-20 01:01:34.279
cmkg60upg000k13oysia114hc	paciente20@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Francisco Silva Contreras	10000019-1	t	\N	NUNOA	\N	Masculino	Calle 20 # 387, NUNOA	1963-03-10 04:00:00	\N	\N	2026-01-16 00:53:53.139	2026-01-16 00:53:53.14	2026-01-20 01:01:34.282
cmkg60uph000l13oyck35g7ni	paciente21@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Manuel Torres Soto	10000020-2	t	\N	ESTACION CENTRAL	\N	Masculino	Calle 21 # 822, ESTACION CENTRAL	1979-05-22 04:00:00	\N	\N	2026-01-16 00:53:53.141	2026-01-16 00:53:53.141	2026-01-20 01:01:34.284
cmkg60upi000m13oymkzip3z2	paciente22@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Javiera Morales Perez	10000021-3	t	\N	SAN MIGUEL	\N	Masculino	Calle 22 # 744, SAN MIGUEL	1960-09-13 04:00:00	\N	\N	2026-01-16 00:53:53.142	2026-01-16 00:53:53.143	2026-01-20 01:01:34.286
cmkg60upj000n13oymy1umlko	paciente23@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Jose Gonzalez Fuentes	10000022-4	t	\N	PUENTE ALTO	\N	Masculino	Calle 23 # 694, PUENTE ALTO	1952-05-22 04:00:00	\N	\N	2026-01-16 00:53:53.143	2026-01-16 00:53:53.144	2026-01-20 01:01:34.287
cmkg60upl000o13oyprnc9f6k	paciente24@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Luis Martinez Silva	10000023-5	t	\N	ESTACION CENTRAL	\N	Masculino	Calle 24 # 488, ESTACION CENTRAL	1979-03-22 04:00:00	\N	\N	2026-01-16 00:53:53.145	2026-01-16 00:53:53.145	2026-01-20 01:01:34.289
cmkg60upm000p13oyuw8z7h3x	paciente25@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Carolina Torres Morales	10000024-6	t	\N	QUILICURA	\N	Femenino	Calle 25 # 421, QUILICURA	1999-12-18 03:00:00	\N	\N	2026-01-16 00:53:53.146	2026-01-16 00:53:53.147	2026-01-20 01:01:34.291
cmkg60upn000q13oyewhxjhtp	paciente26@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Maria Silva Diaz	10000025-7	t	\N	ESTACION CENTRAL	\N	Otro	Calle 26 # 837, ESTACION CENTRAL	1995-08-26 04:00:00	\N	\N	2026-01-16 00:53:53.147	2026-01-16 00:53:53.148	2026-01-20 01:01:34.292
cmkg60upo000r13oy0qojz76f	paciente27@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Luis Perez Lopez	10000026-8	t	\N	QUILICURA	\N	Femenino	Calle 27 # 950, QUILICURA	1965-10-11 04:00:00	\N	\N	2026-01-16 00:53:53.148	2026-01-16 00:53:53.149	2026-01-20 01:01:34.293
cmkg60upp000s13oyhz19kyx6	paciente28@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Cristian Soto Rojas	10000027-0	t	\N	LA FLORIDA	\N	Otro	Calle 28 # 123, LA FLORIDA	1972-12-21 03:00:00	\N	\N	2026-01-16 00:53:53.149	2026-01-16 00:53:53.15	2026-01-20 01:01:34.295
cmkg60upr000t13oy51oqrhfq	paciente29@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Camila Gonzalez Rodriguez	10000028-1	t	\N	SANTIAGO	\N	Femenino	Calle 29 # 90, SANTIAGO	1973-09-08 04:00:00	\N	\N	2026-01-16 00:53:53.15	2026-01-16 00:53:53.151	2026-01-20 01:01:34.297
cmkg60ups000u13oy3xejongw	paciente30@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Maria Rodriguez Soto	10000029-2	t	\N	PENALOLEN	\N	Masculino	Calle 30 # 900, PENALOLEN	1955-02-25 04:00:00	\N	\N	2026-01-16 00:53:53.151	2026-01-16 00:53:53.152	2026-01-20 01:01:34.298
cmkg60uop000213oyc39qzj1l	paciente2@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Camila Flores Soto	10000001-1	t	\N	VITACURA	\N	Masculino	Calle 2 # 485, VITACURA	1973-11-16 03:00:00	\N	\N	2026-01-16 00:53:53.113	2026-01-16 00:53:53.113	2026-01-20 01:01:34.252
cmkg62yju002qzvodse3oh1je	test-1768524928815@example.com	$2b$10$5Qwfmjev0v0Xo6T2bpveL.baXeLTUB2lfvJ9pDzrtigGvYBpbzs/.	Test Auth User	11.222.836-1	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:55:31.434	2026-01-16 00:55:31.434
cmkg64y4p002rzvod49vwg25g	iphone_login_1768525021132@test.com	$2b$10$FmNWZKv2peXTk9mjxRj0wuz4JsQXqN5WwnbmKjbs.hYiGtkLRMS8.	iPhone Test User	12.858.505-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:57:04.201	2026-01-16 00:57:04.201
cmkg651zc002szvodevayf918	ipad_login_1768525027868@test.com	$2b$10$a2/FHHoo8c5aFsF1/QyT3eEmOQkO7LTAHfN6P0x6jJgp1l40wNWT2	iPad Test User	11.547.673-4	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:57:09.192	2026-01-16 00:57:09.192
cmkg658ve002tzvodwbw8del8	iphone_profile_1768525032669@test.com	$2b$10$IFSstl9BCQBgWTDJ8BtOCunRvN2j19OMLyqP5j.60QXOG2/lVALLK	iPhone Profile User	12.187.695-3	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:57:18.122	2026-01-16 00:57:18.122
cmkg65cyu002vzvodcwn9dr1p	mobile_dv_1768525040144@test.com	$2b$10$rHb64m29967QSO/q8Z6Qe.tK1IcNHJfl/AiontuXK7UPI6d1hUb4G	Mobile DV User	17.845.776-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:57:23.43	2026-01-16 00:57:23.43
cmkg65cyu002uzvod3e7y7xlo	mobile_rut_1768525039895@test.com	$2b$10$qFWOoLr2l9oxrdY5GRvdMe1fkFgAuqf2jYrIQ/ytt3v05r.sbISSy	Mobile RUT User	13.290.684-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:57:23.43	2026-01-16 00:57:23.43
cmkg65k0c002wzvodywngdraa	touch_rut_1768525049262@test.com	$2b$10$xArCRKd3HaR6M0U5JFkB9u9.ia1ItWwN3D4syeRpPGlRChHsacE6q	Touch RUT User	16.798.961-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:57:32.556	2026-01-16 00:57:32.556
cmkg65k0d002xzvodc53wpvn2	phone_update_rut_1768525049262@test.com	$2b$10$qyzaUkTwYv4F/CRqIWi1nekggIaudC/dBqDSPFYL0CvtpCpULKQ3G	Phone Update User	11111111-K	t		SANTIAGO	\N			\N		\N	\N	2026-01-16 00:57:32.556	2026-01-16 00:57:40.345
cmkg65rzj002yzvodomrg2u1h	ipad_profile_1768525060416@test.com	$2b$10$JkK3tUWATgR/W5bKm.ljQ.Hyc7mee8XvMmwQb6w5Omi7zC0po2VBG	iPad Profile User	13.222.679-8	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:57:42.895	2026-01-16 00:57:42.895
cmkg65xnv002zzvodfy48ydla	ipad_update_1768525067757@test.com	$2b$10$8Eh8/s5tzUt66DJo6hwTo.wIM2zzAHu0CWNjsqnqtrT2p028qUGgy	iPad Update User	10.893.909-0	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:57:50.251	2026-01-16 00:57:50.251
cmkg663ep0030zvodvlakgd7l	ipad_spacing_1768525072200@test.com	$2b$10$nz8EW5K13i2wrmazDPXMr.Iam0m2M36QqMB6iNL.oHh./tx1zapxW	iPad Spacing User	10.930.487-4	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:57:57.697	2026-01-16 00:57:57.697
cmkg6672t0031zvodtf7x6wxo	mobile_grid_1768525079633@test.com	$2b$10$39/SP6Ry7Y.TLinOKSRWq.7KJekc9u4gn/oBM7HbCRG.lnSH2kuYq	Mobile Grid User	19.049.850-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:58:02.454	2026-01-16 00:58:02.454
cmkg66af10032zvodztzlt15j	tablet_selectors_1768525084590@test.com	$2b$10$HSKuu/19qK1vP50TBNhw8u1pJrsOoWB62hiwNhgnfJBjAVDUJ.VMC	Tablet Selectors User	19.206.408-3	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:58:06.782	2026-01-16 00:58:06.782
cmkg60upx000x13oyi3zct6aj	paciente33@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Camila Valenzuela Martinez	10000032-5	t	\N	PUENTE ALTO	\N	Femenino	Calle 33 # 217, PUENTE ALTO	1973-10-22 03:00:00	\N	\N	2026-01-16 00:53:53.157	2026-01-16 00:53:53.157	2026-01-20 01:01:34.303
cmkg60upy000y13oyuirdzdrp	paciente34@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Carolina Torres Morales	10000033-6	t	\N	LA FLORIDA	\N	Femenino	Calle 34 # 258, LA FLORIDA	1982-08-06 04:00:00	\N	\N	2026-01-16 00:53:53.158	2026-01-16 00:53:53.158	2026-01-20 01:01:34.304
cmkg60upz000z13oy70hhs2cs	paciente35@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Javiera Martinez Silva	10000034-7	t	\N	RECOLETA	\N	Masculino	Calle 35 # 654, RECOLETA	1953-08-22 04:00:00	\N	\N	2026-01-16 00:53:53.159	2026-01-16 00:53:53.159	2026-01-20 01:01:34.305
cmkg60uq0001013oyzpghecpp	paciente36@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Carmen Flores Lopez	10000035-8	t	\N	LA CISTERNA	\N	Femenino	Calle 36 # 739, LA CISTERNA	1999-04-17 04:00:00	\N	\N	2026-01-16 00:53:53.16	2026-01-16 00:53:53.16	2026-01-20 01:01:34.307
cmkg60uq1001113oyd2uivwqm	paciente37@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Daniela Soto Valenzuela	10000036-0	t	\N	MACUL	\N	Masculino	Calle 37 # 345, MACUL	1979-06-18 04:00:00	\N	\N	2026-01-16 00:53:53.161	2026-01-16 00:53:53.161	2026-01-20 01:01:34.309
cmkg60uq2001213oyf0yb20xn	paciente38@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Carmen Flores Munoz	10000037-1	t	\N	LA FLORIDA	\N	Otro	Calle 38 # 773, LA FLORIDA	1998-02-10 03:00:00	\N	\N	2026-01-16 00:53:53.162	2026-01-16 00:53:53.162	2026-01-20 01:01:34.312
cmkg60uq3001313oybljj62wg	paciente39@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Camila Munoz Gonzalez	10000038-2	t	\N	NUNOA	\N	Femenino	Calle 39 # 514, NUNOA	1975-12-17 03:00:00	\N	\N	2026-01-16 00:53:53.163	2026-01-16 00:53:53.163	2026-01-20 01:01:34.314
cmkg60uq4001413oykkthr7kn	paciente40@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Constanza Contreras Rodriguez	10000039-3	t	\N	VITACURA	\N	Otro	Calle 40 # 417, VITACURA	1981-12-06 03:00:00	\N	\N	2026-01-16 00:53:53.164	2026-01-16 00:53:53.164	2026-01-20 01:01:34.316
cmkg60uq5001513oyyf5bsrfb	paciente41@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Francisca Rojas Espinoza	10000040-4	t	\N	MAIPU	\N	Femenino	Calle 41 # 728, MAIPU	1956-09-24 04:00:00	\N	\N	2026-01-16 00:53:53.165	2026-01-16 00:53:53.165	2026-01-20 01:01:34.318
cmkg60uq6001613oyzf3mg18m	paciente42@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Valentina Soto Araya	10000041-5	t	\N	PROVIDENCIA	\N	Femenino	Calle 42 # 694, PROVIDENCIA	1955-09-17 04:00:00	\N	\N	2026-01-16 00:53:53.166	2026-01-16 00:53:53.166	2026-01-20 01:01:34.319
cmkg60uq7001713oyac9toh5p	paciente43@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Daniela Espinoza Soto	10000042-6	t	\N	LA CISTERNA	\N	Otro	Calle 43 # 501, LA CISTERNA	1968-07-21 04:00:00	\N	\N	2026-01-16 00:53:53.167	2026-01-16 00:53:53.167	2026-01-20 01:01:34.321
cmkg60uq8001813oywt0i2a5p	paciente44@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Constanza Contreras Soto	10000043-7	t	\N	RECOLETA	\N	Masculino	Calle 44 # 154, RECOLETA	1955-08-05 04:00:00	\N	\N	2026-01-16 00:53:53.168	2026-01-16 00:53:53.168	2026-01-20 01:01:34.322
cmkg60uq9001913oyewfv6gmb	paciente45@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Ana Perez Torres	10000044-8	t	\N	SAN MIGUEL	\N	Masculino	Calle 45 # 701, SAN MIGUEL	1965-11-20 04:00:00	\N	\N	2026-01-16 00:53:53.169	2026-01-16 00:53:53.169	2026-01-20 01:01:34.324
cmkg60uqa001a13oygi60bmyr	paciente46@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Valentina Fuentes Araya	10000045-0	t	\N	PROVIDENCIA	\N	Masculino	Calle 46 # 662, PROVIDENCIA	1974-04-06 04:00:00	\N	\N	2026-01-16 00:53:53.17	2026-01-16 00:53:53.171	2026-01-20 01:01:34.325
cmkg60uqb001b13oyl3o4d86e	paciente47@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Diego Lopez Morales	10000046-1	t	\N	PENALOLEN	\N	Femenino	Calle 47 # 180, PENALOLEN	1983-06-19 04:00:00	\N	\N	2026-01-16 00:53:53.171	2026-01-16 00:53:53.172	2026-01-20 01:01:34.328
cmkg60uqc001c13oye3qvuuy7	paciente48@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Jose Contreras Soto	10000047-2	t	\N	MACUL	\N	Masculino	Calle 48 # 71, MACUL	1950-05-10 04:00:00	\N	\N	2026-01-16 00:53:53.172	2026-01-16 00:53:53.173	2026-01-20 01:01:34.33
cmkg60uqd001d13oyc6ibadd0	paciente49@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Carlos Martinez Espinoza	10000048-3	t	\N	MACUL	\N	Otro	Calle 49 # 737, MACUL	1970-07-09 04:00:00	\N	\N	2026-01-16 00:53:53.173	2026-01-16 00:53:53.174	2026-01-20 01:01:34.332
cmkg60uqe001e13oyjugqyaca	paciente50@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Javiera Fuentes Flores	10000049-4	t	\N	LAS CONDES	\N	Femenino	Calle 50 # 165, LAS CONDES	1985-02-16 03:00:00	\N	\N	2026-01-16 00:53:53.174	2026-01-16 00:53:53.175	2026-01-20 01:01:34.333
cmkg60upw000w13oy7iagjlpi	paciente32@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Javiera Martinez Gonzalez	10000031-4	t	\N	LA FLORIDA	\N	Femenino	Calle 32 # 883, LA FLORIDA	1953-12-14 04:00:00	\N	\N	2026-01-16 00:53:53.155	2026-01-16 00:53:53.156	2026-01-20 01:01:34.301
cmkg66l5y0033zvod31ebkqah	patient_1768525097214@test.com	$2b$10$n0ACmahiyCpD9AuUTlxjQetwj5gYp1fSCtC07hqe7tlu17qwOL19i	Test Patient	52.098.856-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:58:20.71	2026-01-16 00:58:20.71
cmkg6860r0036zvodjlgyogag	profile-test-1768525172488@example.com	$2b$10$7oHKelP0XcjiTmWxeYW1weTkmTfEA6qPW6x4q35OHyavmqxUyasle	Profile Test User	19.129.344-8	t	+56 9 8765 4321	VIÑA DEL MAR	\N	Masculino		\N	ISAPRE	\N	\N	2026-01-16 00:59:34.395	2026-01-16 00:59:37.564
cmkg68a080037zvodjs4m0y3r	portal_test_1768525179181@test.com	$2b$10$aUrBEhAAGunnZex3BW/DBeDRq5YitowW7L/E65vKqH.ySKFCrjXCC	Portal Test Patient	13.996.810-6	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:59:39.56	2026-01-16 00:59:39.56
cmkg68h400038zvodpmbrk3ty	logout_test_1768525188223@test.com	$2b$10$siQ1NV54X4cMxGM9I0X4IOTfFsYzkcuzNsADXg1xhiyD0TPBXMGPy	Logout Test Patient	10.798.812-3	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 00:59:48.768	2026-01-16 00:59:48.768
cmkg6pcbe0039zvod4l8b9a9u	new_patient_1768525975295@test.com	$2b$10$uE0.zk8D1FBvxdjq0XgMBOxFAe.c.dhhvP66nNDGr5NwQvzBEqpbW	Paciente E2E	14741359-8	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-16 01:12:55.706	2026-01-16 01:12:55.706
cmkg6pzjo003czvodct63ba9o	test-1768526004883@example.com	$2b$10$s1hrguvarBTy5QndVpN/XusKAnXcWZNJyN3p83HXA2JRq1WRgdCYK	Test Auth User	15.900.419-6	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:13:25.812	2026-01-16 01:13:25.812
cmkg6qik7003dzvodonezqdvi	iphone_login_1768526029303@test.com	$2b$10$PdHwyjDftbnfeToiUIxyw.uEuAubRm2Tl.Q24Oyhq6RFn6NezAwL2	iPhone Test User	10.771.319-8	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:13:50.456	2026-01-16 01:13:50.456
cmkg6qq6a003ezvodigifv2n8	ipad_login_1768526039233@test.com	$2b$10$Uj9WoksTrjxj0BAflKoanOek9iq7ZomuzaymOLq6Ktsp8V.8bbLZ.	iPad Test User	12.127.539-6	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:14:00.322	2026-01-16 01:14:00.322
cmkg6qx64003fzvodjglvmg3c	iphone_profile_1768526048680@test.com	$2b$10$9g3OYNLf87riebI3xZbZ/O9qYOhdbX2ltONDzmM7DGPVBZ86ialXK	iPhone Profile User	18.430.595-3	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:14:09.388	2026-01-16 01:14:09.388
cmkg6r1a9003gzvod9pmjzwv3	mobile_rut_1768526052944@test.com	$2b$10$pMgWe4mCGSZKxe6U6gWuleGsbSdXnzncV67OMmvpJ2H08I9VTaqey	Mobile RUT User	14.886.244-0	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:14:14.721	2026-01-16 01:14:14.721
cmkg6r71r003hzvodyokaqqx7	mobile_dv_1768526057612@test.com	$2b$10$GnmcFoiCr7//6W4uLbvUI.q/3wd3hCPPnbXFBnglelqv95L3JWlSa	Mobile DV User	16.827.389-3	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:14:22.191	2026-01-16 01:14:22.191
cmkg6rdsz003izvod1978sc55	phone_update_rut_1768526068076@test.com	$2b$10$jseQE3cRJCVjCx7YGZPjN.adfwA.8CUP16gtbe1Ksz3kXqeRNffQa	Phone Update User	17.381.121-6	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:14:30.947	2026-01-16 01:14:30.947
cmkg6rn8y003jzvodw4qesama	touch_rut_1768526081567@test.com	$2b$10$cyvsW.RBbzAE8dCgiMlbHexLZqj/BYr/uUYlGr1dxdyUsKQobdVFy	Touch RUT User	19.649.590-8	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:14:43.186	2026-01-16 01:14:43.186
cmkg6rrxi003kzvodg5178adn	ipad_profile_1768526086922@test.com	$2b$10$V0djPzoMH3/Q3DEmw3tHDukyvEucIte9b7ukOlmdBqhV/43U5W8oy	iPad Profile User	16.431.440-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:14:49.255	2026-01-16 01:14:49.255
cmkg6rwd8003lzvodsd0wei10	ipad_update_1768526092500@test.com	$2b$10$kBh5iqUghoWT3.7Ev6NB9eK7ifKXA2JIVulas4tK0yoJ.lIsTeo26	iPad Update User	19.736.980-0	t	+56 9 8888 7777	VIÑA DEL MAR	\N	Femenino		\N	ISAPRE	\N	\N	2026-01-16 01:14:55.002	2026-01-16 01:14:58.4
cmkg6s1vt003mzvodyza5x2y1	ipad_spacing_1768526101135@test.com	$2b$10$GhZvlKqU4AOIyCFYE8Q3YeTptxsvRjMymNqGpINUEwV9NRVpiKLSm	iPad Spacing User	15.157.885-6	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:15:02.151	2026-01-16 01:15:02.151
cmkg6s5w5003nzvod3y88w7d0	mobile_grid_1768526105050@test.com	$2b$10$4sDK.yQCE1t.DUSzpUSjm.jkajkzxfXpRj54K1vWP4TC8/byMilK.	Mobile Grid User	14.418.088-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:15:07.349	2026-01-16 01:15:07.349
cmkg6s8ty003ozvod23g48n0p	tablet_selectors_1768526110490@test.com	$2b$10$ku1MnlBaywwuXnw5x.Z2KuOdZu9RkdRQQGkIG/kJIezeChI4DKcIa	Tablet Selectors User	17.595.899-6	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:15:11.158	2026-01-16 01:15:11.158
cmkg6wbbz003pzvodlso90ivh	patient_1768526298246@test.com	$2b$10$t19OVvjgh9HRQ8i1LyuVMOtYqeCA7NGrkOlFvDbmE94eKKuoAoftW	Test Patient	17.382.547-0	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:18:21.023	2026-01-16 01:18:21.023
cmkg6xs0o003szvod6jbweu25	profile-test-1768526367775@example.com	$2b$10$3TdszDX5HwaS/p6EBRp1WO.6NoO.0g0lh8hdMiwrJIVcjADdNfh3a	Profile Test User	15.900.132-7	t	+56 9 8765 4321	VIÑA DEL MAR	\N	Masculino		\N	ISAPRE	\N	\N	2026-01-16 01:19:29.305	2026-01-16 01:19:32.726
cmkg6xvzf003tzvod79izp9y9	portal_test_1768526373969@test.com	$2b$10$UGEd3QSmGdfnuq36pkybhuyge4I4WlcN7dBAPKIUeofZauKSEX66O	Portal Test Patient	13.936.831-7	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:19:34.443	2026-01-16 01:19:34.443
cmkg6y3z5003uzvodwoy5qrxp	logout_test_1768526384418@test.com	$2b$10$Vhi/fpWBIe3TxA3Rh3V3A.ngaHi/EZp7RQyHku97ZWaC59QjqzSPW	Logout Test Patient	11.071.844-1	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:19:44.802	2026-01-16 01:19:44.802
cmkg70law003yzvodrp6k3hw8	new_patient_1768526498531@test.com	$2b$10$GcgDPu9Eb020Rdf8ftZoZeTQePtny7yHL9azqUj1Sp7Y6/AoA8WG2	Paciente E2E	17789766-4	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-16 01:21:40.569	2026-01-16 01:21:40.569
cmkg7107v0041zvodd83d6g68	test-1768526517930@example.com	$2b$10$bG9h/Z2jPAYOef5Fk5MA9Or4qyueKTOxXktSTv.3QByJV6azwrbW2	Test Auth User	19.841.814-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:21:59.9	2026-01-16 01:21:59.9
cmkg71mdw0042zvodx0i6aryo	iphone_login_1768526536813@test.com	$2b$10$LOmeUof37eLsQT2EpPFuHuEFyQs0B6cnBgsKywQ/ABOFqbOo0FDZ.	iPhone Test User	14.135.602-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:22:28.602	2026-01-16 01:22:28.602
cmkg72s2c0043zvoddrqxur2w	ipad_login_1768526577328@test.com	$2b$10$83zuSkeYuaX9f3ddqnFgUu5jOl6mfgvS1zf7Yya65hkn9ozblr0HC	iPad Test User	13.361.736-0	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:23:22.643	2026-01-16 01:23:22.643
cmkg731970044zvod3pm5xj1n	iphone_profile_1768526612200@test.com	$2b$10$Q643e.0hhMC9tz79BOYSfeKzsPJjEtJwuDhfg54NItQVJJUswH762	iPhone Profile User	18.140.197-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:23:34.547	2026-01-16 01:23:34.547
cmkg732ev0045zvod8ulb29hd	mobile_rut_1768526613448@test.com	$2b$10$2gjsFIvJWqGOWaniFuCOye9igitSPu/QQO78bKQXCIU71Hw9IVzn.	Mobile RUT User	13.271.004-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:23:36.056	2026-01-16 01:23:36.056
cmkg736q60046zvodcyya6d1l	mobile_dv_1768526619834@test.com	$2b$10$GFYHtXRJs8tMoho1/Xj.F.FTT/HITvyehL3Uzf9Yd/n1u5cvsvYy.	Mobile DV User	16.348.759-4	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:23:41.646	2026-01-16 01:23:41.646
cmkg73d1s0047zvodpou98jkf	phone_update_rut_1768526625185@test.com	$2b$10$iDtR9qcZP03m2DSDSczYV.65gjBZKumAFiONO8VZB3E47ZRSvAJqu	Phone Update User	18.156.939-4	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:23:49.84	2026-01-16 01:23:49.84
cmkg73f440048zvod7jackd12	touch_rut_1768526630580@test.com	$2b$10$8P6w3Hzb3GuF84v3jlVBoeOP0ESNh2xmCxAuTHeTwyWsQ1Icm2nVm	Touch RUT User	18.696.278-3	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:23:52.517	2026-01-16 01:23:52.517
cmkg73t9a004azvoduihnazk5	ipad_profile_1768526646897@test.com	$2b$10$cgueidQl6tq/3HDxVNBceO/tyJZ61i5MZpfq3Hau42eUwa95OjwSC	iPad Profile User	16.544.525-8	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:24:10.846	2026-01-16 01:24:10.846
cmkg73rk30049zvodbmmaftxh	ipad_update_1768526641766@test.com	$2b$10$GX3nItapvjnwcAGrfXrF0uiSGI7bYVqqIVs4KZIvnY8BJU7ZQvIXW	iPad Update User	11.765.856-1	t	+56 9 8888 7777	VIÑA DEL MAR	\N	Femenino		\N	ISAPRE	\N	\N	2026-01-16 01:24:08.644	2026-01-16 01:24:15.937
cmkg73zh8004bzvodht0jn35b	ipad_spacing_1768526656949@test.com	$2b$10$4R7jgeDnHyaDD5VvHXfRkOkkKm00S/2XulT1Mz.CsE91xuP51AOOu	iPad Spacing User	14.022.125-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:24:18.909	2026-01-16 01:24:18.909
cmkg742a8004czvod2zszmugg	mobile_grid_1768526660791@test.com	$2b$10$ncNEnvhQBg49Lu5uJiDtrOzGEJ4VVJjcIUXTqV4wH3BqU8HULciTm	Mobile Grid User	15.152.916-4	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:24:22.544	2026-01-16 01:24:22.544
cmkg745xo004dzvodp1iaaezv	tablet_selectors_1768526663381@test.com	$2b$10$y029NfyTvacYhqpFGNFOkeeNlvLXXt8dTnMXkrFzcjxg6stxZ.MJm	Tablet Selectors User	19.097.102-0	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:24:27.268	2026-01-16 01:24:27.268
cmkg74eew004ezvodasjaluzp	patient_1768526675549@test.com	$2b$10$2r27T4Dpf9YLPevcOLwSP.Vk5/XYRiota8/7o3FoIDeOB0jhHfdM.	Test Patient	64.113.134-3	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:24:38.265	2026-01-16 01:24:38.265
cmkg74ms4004fzvode4adj0y7	profile-test-1768526687459@example.com	$2b$10$.tkq2dP8IjKLLSiBwrfdxOy1jeR2HQHLLFJWN.EgMELRAtLFJutF2	Profile Test User	10.069.891-7	t	+56 9 8765 4321	VIÑA DEL MAR	\N	Masculino		\N	ISAPRE	\N	\N	2026-01-16 01:24:49.108	2026-01-16 01:24:52.329
cmkg74rhn004gzvodd8svmjm6	portal_test_1768526694590@test.com	$2b$10$8t6nK.lOpR4MbTP12ELvNOV5otUzmk8zFDUrgpffaqW/nLZoUt1e2	Portal Test Patient	18.969.648-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:24:55.211	2026-01-16 01:24:55.211
cmkg74y8f004hzvod2th2qoul	logout_test_1768526703453@test.com	$2b$10$MTnwCOYahbqapadSfKwv4eiQLSwxW7iEzw7jMDTuAUpRnyGv2tI9O	Logout Test Patient	16.902.431-1	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:25:03.948	2026-01-16 01:25:03.948
cmkg7dzb4004nzvodw1dfo5b0	test-1768527112177@example.com	$2b$10$oV4/zM9wD4QIHV9F0XwWcueEKh5Pzs.UfxSd3NO3wAZ6iaDpMIVOe	Test Auth User	17.061.781-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:32:05.248	2026-01-16 01:32:05.248
cmkg7ecvt004ozvoddlye74rv	iphone_login_1768527136558@test.com	$2b$10$/HRUNTZuAQu0jqarUgKLfun4nYIHe90JjCyBcia9gigvBcfYw63Nq	iPhone Test User	12.607.851-1	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:32:22.841	2026-01-16 01:32:22.841
cmkg7ejy4004pzvodj4qqjdyv	ipad_login_1768527144709@test.com	$2b$10$2rNYkYl1ELXyCU.09AjY..YgBa7KBoYOynpA2JiD28/CsxyFDIgWC	iPad Test User	19.008.832-4	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:32:31.996	2026-01-16 01:32:31.996
cmkg7erz5004qzvodd2hz1zaj	profile-test-1768527156423@example.com	$2b$10$ImcW1JfUGQLTKwIP7eDzuOedp3z7jj.GO6cGzYtrmTjGas8DXGura	Profile Test User	16.282.201-6	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:32:42.401	2026-01-16 01:32:42.401
cmkg7ew5d004rzvodobjdmir1	patient_1768527159245@test.com	$2b$10$tpICA/4dUYbV3ZQmlpjVuei7z1b500KTkiZLNYoou0hz29CYIH/pq	Test Patient	40.892.459-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:32:47.81	2026-01-16 01:32:47.81
cmkg7eye9004szvoddsb4pbgk	portal_test_1768527167091@test.com	$2b$10$UmQnGIY/xL8C0SIYovH0Au7S3Hel8H5YLNiy42hU2/M4RcYZHCD7.	Portal Test Patient	11.515.911-1	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:32:50.722	2026-01-16 01:32:50.722
cmkg7f2kw004tzvoddjjt7uii	logout_test_1768527175200@test.com	$2b$10$bMXdk0g81WODpoAm.FLjG.08DC.kHU1oktPk9b2ieHA/oi2AS2pUu	Logout Test Patient	12.712.668-8	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-16 01:32:56.144	2026-01-16 01:32:56.144
cmklvusnu00047890k5c1sdzq	test-1768870547758@example.com	$2b$10$96KKI9s26oD.w4J535b40.im6If6fNVv3Rk.apAOocLnZ5R0A7cG2	Test Auth User	17.082.344-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 00:55:51.451	2026-01-20 00:55:51.451
cmkg60up6000e13oyj554ift1	paciente14@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Carolina Lopez Hernandez	10000013-4	t	\N	SAN MIGUEL	\N	Masculino	Calle 14 # 430, SAN MIGUEL	1968-02-25 04:00:00	\N	\N	2026-01-16 00:53:53.13	2026-01-16 00:53:53.131	2026-01-20 01:01:34.271
cmklver020002cgopshh0cnxf	new_patient_1768869802300@test.com	$2b$10$ChZiHTvCIS8VbgOK61b0Run.DhV9iKU5ADFewzXDquuj//uHqlgle	Paciente E2E	15210702-0	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 00:43:22.803	2026-01-20 00:43:22.803
cmklvgoq90008cgopkq00xhxf	new_patient_1768869892611@test.com	$2b$10$laPvx6rAVzk/4GCMrfDkSuFNl5qSYMoC4/YKWBzeeB0/TESwvaI.a	Paciente E2E	13717322-3	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 00:44:53.169	2026-01-20 00:44:53.169
cmklvjuv4000ecgop96er9dvr	new_patient_1768870040642@test.com	$2b$10$7/d.DcELeNwWtOLzBgHGC.R8oOn.GSpOfgGFYHTdkO5K3nyHJjRye	Paciente E2E	13998223-7	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 00:47:21.088	2026-01-20 00:47:21.088
cmklvm8a7000icgopi2vxkmu5	new_patient_1768870151612@test.com	$2b$10$Jlksw9EAvVQgye/zHE90Re4QFIZ2pnwsWNaHv7OXRElg22JEdFRTa	Paciente E2E	11138207-5	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 00:49:11.791	2026-01-20 00:49:11.791
cmklvul9200027890sd38hjgf	new_patient_1768870541304@test.com	$2b$10$vImJ1bK3IH1ZUINGvhYz5eeL.qWuvuUdkJmzPQg4hN6VhtRw2CR8K	Paciente E2E	12988661-1	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 00:55:41.846	2026-01-20 00:55:41.846
cmklvushz00037890l73aovtr	iphone_login_1768870548732@test.com	$2b$10$s1Hq9XI9c9lhu.MD8dq8IOw1R0Xm4Jy8KwUe1Dwt2dG6iTto7FRvO	iPhone Test User	14.328.744-6	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 00:55:51.239	2026-01-20 00:55:51.239
cmklvuvl5000578908u1xlvk5	ipad_login_1768870554381@test.com	$2b$10$e4OjUA42E905uH.ZfJRDBunpFDxMZASf2aIh9wjfrrOc59BYxYWzq	iPad Test User	18.767.534-7	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 00:55:55.241	2026-01-20 00:55:55.241
cmklvv9nk00067890unufkvst	patient_1768870570939@test.com	$2b$10$zOAjjJ4qhv2itdus19e3GOpqdEWeDWUMl4VCMtcQuVFQNm65shg0.	Test Patient	33.997.841-8	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 00:56:13.472	2026-01-20 00:56:13.472
cmklvw8ys000978903ym0ocjh	portal_test_1768870618758@test.com	$2b$10$F..UwSZcLBRBPOB7p2MogOoCCm.7PgiZF9SnDttKB8oRM2s9fZJ4u	Portal Test Patient	11.234.630-1	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 00:56:59.237	2026-01-20 00:56:59.237
cmklvw8ys000a7890h05mlke7	profile-test-1768870618304@example.com	$2b$10$IYXWZO546LYQBO.zt3WrCOBzDDIhe5gY6mV3K76r9Gn.7wbsXabim	Profile Test User	17.110.200-8	t	+56 9 8765 4321	VIÑA DEL MAR	\N	Masculino		\N	ISAPRE	\N	\N	2026-01-20 00:56:59.237	2026-01-20 00:57:03.323
cmklvwd12000b78907unkq7i5	logout_test_1768870624212@test.com	$2b$10$8PspKnllcYYcyUOnsWn5I.OXsrBLdnp7MNZ.m7LEJ3quzbe5gtkLO	Logout Test Patient	10.607.991-1	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 00:57:04.503	2026-01-20 00:57:04.503
cmklvx26o000h7890x5ntv3rx	new_patient_1768870656401@test.com	$2b$10$gIvj98aLL6eM4AwC61c6TuHP6wh9UnB6/sPjzoOOuFG/NrvcTbs/i	Paciente E2E	12693628-8	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 00:57:37.104	2026-01-20 00:57:37.104
cmklvxft6000i789037064j07	test-1768870673586@example.com	$2b$10$5GE1USZX8iDCERqqJL0gpeQXdnbCLbabuyDHeuxiaJRfsbfbpPwUS	Test Auth User	14.451.150-1	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 00:57:54.762	2026-01-20 00:57:54.762
cmklvxovh000j7890so4zpjeg	iphone_login_1768870685837@test.com	$2b$10$D2C5zpDsAz0IRtXqXxMgDu.ZqKsMZeTUtubIRCL3YcySL8TxnN0ca	iPhone Test User	17.735.000-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 00:58:06.509	2026-01-20 00:58:06.509
cmklvxve3000k78907lg6vkso	ipad_login_1768870692987@test.com	$2b$10$ukBLCyTVui5cnG7eud.Mk.bQvzh2LAFRjt4PGY7D4BQw2igjRlwAi	iPad Test User	12.805.882-1	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 00:58:14.955	2026-01-20 00:58:14.955
cmklvz5ff000l7890uephpek7	patient_1768870752131@test.com	$2b$10$lPQkeyhgTC0ApxfQIlnDku2QWk9xml3DWZs8c7HwJikDwB313.50K	Test Patient	30.860.805-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 00:59:14.619	2026-01-20 00:59:14.619
cmklw008g000o78903x7fw5p5	portal_test_1768870793914@test.com	$2b$10$24NhuwzV/1.F4wJvEhPjyuuMNMGlhPuL4R/UucPXgep0SKGnlqXbC	Portal Test Patient	13.934.634-7	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 00:59:54.544	2026-01-20 00:59:54.544
cmklw03fy000p7890nic72l2p	logout_test_1768870798158@test.com	$2b$10$MNYy06LxFDwwbC2pFMOYeepSJkgENAJOh7J7VC3CeTbHnT7ZrrtJK	Logout Test Patient	14.346.909-5	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 00:59:58.702	2026-01-20 00:59:58.702
cmklw0w1t000v7890hffrl8r4	new_patient_1768870834967@test.com	$2b$10$HuC1E0YXh6K2pmCI24FtE.XMbCgr6rYcZL6NwYZ6isnsmV3vMP8au	Paciente E2E	15372501-6	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 01:00:35.778	2026-01-20 01:00:35.778
cmkg60upt000v13oybi0j8lnb	paciente31@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Juan Flores Lopez	10000030-3	t	\N	RECOLETA	\N	Femenino	Calle 31 # 875, RECOLETA	1990-07-11 04:00:00	\N	\N	2026-01-16 00:53:53.153	2026-01-16 00:53:53.153	2026-01-20 01:01:34.3
cmklw14bd000w7890yh47c71g	test-1768870844085@example.com	$2b$10$ghKYfYJfQf.VPSJ87.xYa.TlgHbpRhlYltVoXapbw.BM5ngPyBMnG	Test Auth User	19.020.331-0	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:00:46.489	2026-01-20 01:00:46.489
cmklw18ly000x7890on3h8qxd	iphone_login_1768870849731@test.com	$2b$10$f0mmYV7sFNs8jp4CH0DluuvhS9MA2s7uyum9l6/r55.b9vfy.z7fy	iPhone Test User	15.464.561-8	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:00:52.054	2026-01-20 01:00:52.054
cmklw1c8s000y7890034kkb26	ipad_login_1768870854959@test.com	$2b$10$1ehePvC9E7M76Vbe6BOgveSpLPqoOWATwkcfuV8hpm1TNJRZu5r36	iPad Test User	10.633.376-3	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:00:56.764	2026-01-20 01:00:56.764
cmkg60uol000113oy3mxdf5vt	paciente1@test.com	$2b$10$ZD7g2YpDcP0gC5dEZhm.D.t7xW5CFRnnboxMcxQvZ6fTKay.4f1/W	Pedro Hernandez Sepulveda	10000000-0	t	\N	LA FLORIDA	\N	Otro	Calle 1 # 988, LA FLORIDA	1972-01-03 03:00:00	\N	\N	2026-01-16 00:53:53.109	2026-01-16 00:53:53.11	2026-01-20 01:01:34.246
cmklw26cp000z7890s5c161f1	patient_1768870893055@test.com	$2b$10$toD4/rSRtwMzdWlXLpuc0.ZASoYnyfNYFXkBdlH5zNfhHNuF5V.kG	Test Patient	44.947.659-8	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:01:35.785	2026-01-20 01:01:35.785
cmklw3bcc00127890nlvuspmw	profile-test-1768870929607@example.com	$2b$10$kA78hG6QYHoFuITkdfHXFu8y84O3YMMhW4JjKai3sAtJ9GFryej8u	Profile Test User	15.710.270-8	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:02:28.907	2026-01-20 01:02:28.907
cmklw3goc00137890406a6sxn	test-1768870937914@example.com	$2b$10$MmqiG/eoZLljp1q7AtXg..Ive7tpJB2NflJ.XZvG6seJZkT.G7pXS	Test Auth User	15.576.128-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:02:35.82	2026-01-20 01:02:35.82
cmklw3mqj00147890o7w7kul8	portal_test_1768870962262@test.com	$2b$10$DCiRwhOoj0QorREEsUAAYu/6C.eK.sOWadjZ25POUaWT/1BzHdJS.	Portal Test Patient	16.550.214-3	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:02:43.675	2026-01-20 01:02:43.675
cmklw3thp00157890951jln21	logout_test_1768870969890@test.com	$2b$10$MjVGXeQBeafugLBTf7UMLenueYfHAMdf02ce90cn/f5l3GVWpTFJ.	Logout Test Patient	13.611.568-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:02:52.429	2026-01-20 01:02:52.429
cmklw3zpp00167890ckdlspua	iphone_login_1768870971635@test.com	$2b$10$WBX7m1XJX/JsWGCs7Zb3seu.Uzlou/WYuXrNMQeQYcPaOdxKrfwpS	iPhone Test User	11.709.011-0	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:03:00.493	2026-01-20 01:03:00.493
cmklw49lq00177890xwp1jmta	ipad_login_1768870986208@test.com	$2b$10$RqyCbpLPIxZpiq4SSrYxUeQ4aoSFLLV2CjrlpxZkhfZyU6d8TqeHi	iPad Test User	18.715.080-7	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:03:13.31	2026-01-20 01:03:13.31
cmklw6nmc00187890lk7hk6qk	patient_1768871098546@test.com	$2b$10$f.bJ7QE07Knv90F7/ahjXOcHOLykY0fXWN3YmEEjVF9DHe.uiuZ/W	Test Patient	34.012.582-3	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:05:04.788	2026-01-20 01:05:04.788
cmklw8aqi001a78907kku0ori	profile-test-1768871128682@example.com	$2b$10$BGEsY2EKXrAxYyMPSSSCKeJoY1vdSjHdGUdXwichrTNRaAbMe8./e	Profile Test User	11.000.505-8	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:06:21.402	2026-01-20 01:06:21.402
cmklw8djc001b7890ol1zv48c	portal_test_1768871177703@test.com	$2b$10$df7cbA.J.2.8TXYA5BfqjuWhlhZSKOrTnhbjsdLcyD0gx0jMG4Gm.	Portal Test Patient	14.284.979-3	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:06:25.022	2026-01-20 01:06:25.022
cmklw9bmu001c7890sdiisv8o	logout_test_1768871223204@test.com	$2b$10$T7ap2oEaH93ldsQR5V6gMOUVYq59eMPjwvvH4UGTnR/uhAThy4aou	Logout Test Patient	16.516.660-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:07:09.222	2026-01-20 01:07:09.222
cmklw9faz001d789038v59vb9	test-1768871214105@example.com	$2b$10$CFp4vML40sf/OFEBBDYDWuvv19GaHtA80F/peNWxSK89s5AdGqiu2	Test Auth User	13.817.456-4	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:07:13.979	2026-01-20 01:07:13.979
cmklw9j0l001e7890foqko6dz	test-1768871215615@example.com	$2b$10$tbKr33WsGJrBBsQcHLnNseNoyqPPyj0ArwgxZafpY3UPuseQwExYW	Test Auth User	11.746.434-7	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:07:18.788	2026-01-20 01:07:18.788
cmklwalnv001f78901zxlqa3x	iphone_login_1768871244898@test.com	$2b$10$7CIJr/DZw5JDcSsflZKj7uFdt16Wkcfix0DqDIriYM7L/lYMUbnoy	iPhone Test User	11.079.085-6	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:08:08.874	2026-01-20 01:08:08.874
cmklwbi5s001g7890awkffp4v	ipad_login_1768871294515@test.com	$2b$10$dnaAjGTTDBDwzruYPKwGWOMuarSt5GVad45fcUOKbwdFWcMhtvttO	iPad Test User	17.042.013-8	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:08:50.992	2026-01-20 01:08:50.992
cmklwiz7s001h7890kov9iqge	profile-test-1768871582901@example.com	$2b$10$JlTI.5Ye4VSQCaDR8hTFWeZMtxRqo7hHG1NjqLKcUnisTRCQIRKsm	Profile Test User	15.761.684-0	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:14:39.688	2026-01-20 01:14:39.688
cmklwja4y001i7890kl4ycijm	portal_test_1768871684316@test.com	$2b$10$vtZfZVG.8EHuERqVBm39AeYtEBEB3/0osICH/RhcmDm80Teyzm4f6	Portal Test Patient	18.680.557-6	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:14:53.839	2026-01-20 01:14:53.839
cmklwjoim001j7890zgi5zh9o	profile-test-1768871615997@example.com	$2b$10$ZYPpBbL8IMnl5MheK/p50eom7Ynlq0B6mUB9f5lb0DLsohlHSVn8y	Profile Test User	13.893.640-1	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:15:11.764	2026-01-20 01:15:11.764
cmklwjvxg001k7890hxl2cvoa	portal_test_1768871714329@test.com	$2b$10$9SZBJn3A0TBTQsAhmKI/SuYWAfH2wnJrB0Iv15DDPeEOn3nygkTgS	Portal Test Patient	15.240.428-0	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:15:22.082	2026-01-20 01:15:22.082
cmklwkdyh001l7890ozk612t9	logout_test_1768871738292@test.com	$2b$10$kdhcPzUojESSNqP.z1krPORBlFfXOnDOWWz43c3Juah6js/zUEr5K	Logout Test Patient	17.658.773-3	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:15:45.447	2026-01-20 01:15:45.447
cmklx15w20002nrmcvvawh37w	test-1768872508434@example.com	$2b$10$.jQQ/UryQapNBI/uFOPz9euZyVhQzQwOZaKDYwG2KK/abMPlWO8my	Test Auth User	14.924.828-7	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:28:48.146	2026-01-20 01:28:48.146
cmklx3u9j0000lgh7q9l76l5c	ipad_login_1768872627018@test.com	$2b$10$N0ftAE6QK.6HbRv9zpDA3ejW/p7XSnM0Vne4YSLCXwhZR2hefPk6y	iPad Test User	17.660.604-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:30:53.047	2026-01-20 01:30:53.047
cmklx7vuq0001lgh7yg49ydk0	patient_1768872827221@test.com	$2b$10$G2G1ADaqItvbA4fHuJhPMedubZSu3KwCHXI6llvxWgxcyaN1cT.e2	Test Patient	12.038.623-4	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:34:01.73	2026-01-20 01:34:01.73
cmklx8cge0002lgh7dzcbm6bq	profile-test-1768872831560@example.com	$2b$10$nCPp2VrrRmw61iTlthww5.oO4NrnUqZbAs63bwVrCX2wv6IdmXJ9a	Profile Test User	16.506.248-4	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:34:23.246	2026-01-20 01:34:23.246
cmklx8enn0003lgh7lzj9pjgf	portal_test_1768872857377@test.com	$2b$10$tfD6RkPyOn9d/gtzL0F8Yeqr5IZKSF9kNm.vAcnXKW3T4qtOxsTU6	Portal Test Patient	15.992.770-1	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:34:26.099	2026-01-20 01:34:26.099
cmklx8jrg0004lgh70ys3wo4h	test-1768872853217@example.com	$2b$10$80HtUKKJi/.egJi5/bzoEOZEzjQUr0WMbwzXcJ3LkShwRJVNr.0fC	Test Auth User	19.686.989-2	t	\N	SANTIAGO	\N	\N	\N	\N	\N	\N	\N	2026-01-20 01:34:32.716	2026-01-20 01:34:32.716
cmklyv3cu0000133redvprihl	new_patient_1768875603266@test.com	$2b$10$5ZA0QSrAq7nqBCagxw8nG.FMIf7/FBi6AAa60T0qrkUwK9I9WHjr2	Paciente E2E	26868910-7	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 02:20:04.158	2026-01-20 02:20:04.158
cmklyv3i30001133rhzmgwj5f	new_patient_1768875603406@test.com	$2b$10$MLQXriE6kcHDwP0l3LYhm.F8lunDSukOoH3Coid9UPcgMMIwMsYb6	Paciente E2E	29484646-1	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 02:20:04.348	2026-01-20 02:20:04.348
cmklyv5ud0002133rhjye50e4	new_patient_1768875606729@test.com	$2b$10$/mH7kNTIZ6/14g7UY3UYzuu0./WJiu3OAoNOhfBtb3edDRNqu5MHu	Paciente E2E	21553395-2	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 02:20:07.381	2026-01-20 02:20:07.381
cmklyv8xl0003133rwzsv2o1c	new_patient_1768875610690@test.com	$2b$10$egLE4FWM3/gnhPQf7lko0OJx/3d.XqkxIjxCIOIoq/iuRVZzyZLNa	Paciente E2E	28108487-2	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 02:20:11.385	2026-01-20 02:20:11.385
cmklyx81q00001mazopiaex4t	new_patient_1768875703010@test.com	$2b$10$BNrDHv78AF7b1ww0zsqHWeo.13GcuE.4PP6mWJ8XAcCtHpVFJ6HKi	Paciente E2E	27050244-1	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 02:21:43.55	2026-01-20 02:21:43.55
cmklyx86800011mazn6ucedoc	new_patient_1768875703122@test.com	$2b$10$aaWJU8QSgqc3ney1yUQ6QOiKFp5f.0qhiz8lB/fVKDcOJH7Vn3ZeS	Paciente E2E	20005898-7	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 02:21:43.712	2026-01-20 02:21:43.712
cmklyxawd00021mazp1j9d5gz	new_patient_1768875706654@test.com	$2b$10$1Be6Eh25G73rjSkKwdoPEO2RXsJgTPtfoOEVR6Pezq2nZVAmOoJBW	Paciente E2E	24003676-2	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 02:21:47.245	2026-01-20 02:21:47.245
cmklyxdqe00031mazukdja0r4	new_patient_1768875710695@test.com	$2b$10$v221X/INFwsSEBhQpVW91uvSnVJW2mGxn4gNs5/s83YIc7WsLNPIS	Paciente E2E	27288580-7	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 02:21:50.919	2026-01-20 02:21:50.919
cmklyyf1t000078xwrlrr3dht	new_patient_1768875758842@test.com	$2b$10$aliwXVKZmlyJ9ItnJNIR/.VCsb.swb0ikaZf8YDlYpGbWYiuiUiiO	Paciente E2E	23145659-0	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 02:22:39.282	2026-01-20 02:22:39.282
cmklyyg54000178xwm1ijt0wh	new_patient_1768875759780@test.com	$2b$10$aNamSTS65KlsASe0ax.wW.5KR7hKkxJvzZC.sLSjTj1Usne4M2Y.G	Paciente E2E	27633958-3	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 02:22:40.697	2026-01-20 02:22:40.697
cmklyyjnk000478xwve8rb4fc	new_patient_1768875764620@test.com	$2b$10$3wmE/QXT7Hdim35I2lAuNeB8uYbO/QxCO7Uu4tkGfdbPreXV37tE6	Paciente E2E	23384192-2	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 02:22:45.248	2026-01-20 02:22:45.248
cmklyymm2000978xwpvziccfv	new_patient_1768875768863@test.com	$2b$10$0z8dr7b75I5igzFXXvFhJub19XQEYsUkuT0BnvymjocrDUWfn0Jli	Paciente E2E	23855888-7	t	\N	PROVIDENCIA	Metropolitana	Masculino	Calle Falsa 123	1990-01-01 00:00:00	\N	\N	\N	2026-01-20 02:22:49.082	2026-01-20 02:22:49.082
\.


--
-- Data for Name: PulmonaryFunctionTest; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."PulmonaryFunctionTest" (id, "patientId", date, "cvfValue", "cvfPercent", "vef1Value", "vef1Percent", "dlcoPercent", "walkDistance", "spo2Rest", "spo2Final", "heartRateRest", "heartRateFinal", notes, "createdAt") FROM stdin;
\.


--
-- Data for Name: RolePermission; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."RolePermission" (id, role, action, enabled, "updatedAt") FROM stdin;
cmkg60urm001v13oy8299jwg6	KINESIOLOGIST	Configuración Global	f	2026-01-19 21:39:46.097
cmkg60uro001w13oy6091uid4	RECEPTIONIST	Configuración Global	f	2026-01-19 21:39:46.097
cmkloemii0000a0sf9atjqjg4	KINESIOLOGIST	Crear Pacientes	t	2026-01-19 21:39:46.097
cmkloemj00001a0sfwahxosco	RECEPTIONIST	Crear Pacientes	t	2026-01-19 21:39:46.097
cmkloemk1000aa0sfol884dv9	KINESIOLOGIST	Ver Usuarios	f	2026-01-19 21:39:46.097
cmkloemk6000ba0sfy88xu4ol	RECEPTIONIST	Ver Usuarios	f	2026-01-19 21:39:46.097
cmkg60uqt001i13oybwv5ddln	KINESIOLOGIST	Ver Reportes BI	t	2026-01-19 21:39:46.097
cmkg60urd001s13oyppyxx1qk	RECEPTIONIST	Ver Reportes BI	f	2026-01-19 21:39:46.097
cmkloemkf000ca0sfe6m9ua5a	KINESIOLOGIST	Editar Usuarios	f	2026-01-19 21:39:46.097
cmkloemkr000da0sfoam428mw	RECEPTIONIST	Editar Usuarios	f	2026-01-19 21:39:46.097
cmkloeml0000ea0sf842s32yz	KINESIOLOGIST	Eliminar Usuarios	f	2026-01-19 21:39:46.097
cmkloeml4000fa0sfot0pugsn	RECEPTIONIST	Eliminar Usuarios	f	2026-01-19 21:39:46.097
cmkloemjs0008a0sfy7b8gsz0	KINESIOLOGIST	Crear Usuarios	f	2026-01-19 21:39:46.097
cmkloemjx0009a0sf7smksiku	RECEPTIONIST	Crear Usuarios	f	2026-01-19 21:39:46.097
cmkg60uqg001f13oy83anfvxc	KINESIOLOGIST	Ver Pacientes	t	2026-01-19 21:39:46.097
cmkg60uqv001j13oysvft2zvv	RECEPTIONIST	Ver Pacientes	t	2026-01-19 21:39:46.097
cmkg60uqo001g13oy9a5y8m9j	KINESIOLOGIST	Editar Pacientes	t	2026-01-19 21:39:46.097
cmkg60uqx001k13oyz4wyz724	RECEPTIONIST	Editar Pacientes	t	2026-01-19 21:39:46.097
cmkg60uqq001h13oyezbtry0h	KINESIOLOGIST	Eliminar Pacientes	t	2026-01-19 21:39:46.097
cmkg60ur9001q13oy249cv14k	RECEPTIONIST	Eliminar Pacientes	t	2026-01-19 21:39:46.097
cmkg60urg001t13oykvpyo2cs	KINESIOLOGIST	Gestionar Usuarios	f	2026-01-19 21:39:46.097
cmkg60urj001u13oyhscsnkeg	RECEPTIONIST	Gestionar Usuarios	f	2026-01-19 21:39:46.097
\.


--
-- Data for Name: SystemLog; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."SystemLog" (id, action, details, "userId", "userEmail", "ipAddress", "createdAt") FROM stdin;
cmkg6yt4a003wzvodgr2ksvp5	CREATE_SYSTEM_USER	User created: valid_user_1768526416966@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-16 01:20:17.386
cmkg6z0lj003xzvodhao20ovo	UPDATE_ADMIN_USER	Admin user updated: admin@example.com	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-16 01:20:27.08
cmkg75sdb004jzvodj0e2jbmh	CREATE_SYSTEM_USER	User created: valid_user_1768526742717@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-16 01:25:43.007
cmkg75zfk004kzvodmn1i90gt	UPDATE_SYSTEM_USER	User updated: valid_user_1768526416966@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-16 01:25:52.16
cmkg7dtd3004mzvodege5c5ix	CREATE_SYSTEM_USER	User created: kine_1768527111254@test.com, Role: KINESIOLOGIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-16 01:31:57.543
cmkg7g8af004xzvod7gdufmmc	CREATE_SYSTEM_USER	User created: valid_user_1768527228331@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-16 01:33:50.199
cmkg7gc0r004yzvodw7cexyar	UPDATE_ADMIN_USER	Admin user updated: admin@example.com	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-16 01:33:55.035
cmklofzs1000la0sfs1m2ztqz	UPDATE_PERMISSION	Role: KINESIOLOGIST, Action: Crear Usuarios -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:28:23.522
cmklohjjq000na0sfqv3ikmzg	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Eliminar Pacientes -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:29:35.799
cmklohllf000pa0sf4vg5e7ac	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Ver Usuarios -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:29:38.451
cmklohm81000ra0sfnp9evd19	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Ver Usuarios -> false	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:29:39.265
cmklohoi2000ta0sf3gcoa97r	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Crear Usuarios -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:29:42.218
cmklohpq0000va0sf9fry04p7	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Editar Usuarios -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:29:43.801
cmklohre9000xa0sfd4tffsu7	UPDATE_PERMISSION	Role: KINESIOLOGIST, Action: Editar Usuarios -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:29:45.969
cmklohs13000za0sfolrc1oc0	UPDATE_PERMISSION	Role: KINESIOLOGIST, Action: Eliminar Usuarios -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:29:46.792
cmklohx3w0010a0sfxkfh5ftd	BULK_UPDATE_PERMISSION	Role: RECEPTIONIST -> ALL false	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:29:53.373
cmklohz580011a0sfh15vcpy4	BULK_UPDATE_PERMISSION	Role: RECEPTIONIST -> ALL true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:29:56.012
cmkloi73j0012a0sfr88qebya	BULK_UPDATE_PERMISSION	Role: RECEPTIONIST -> ALL false	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:30:06.319
cmkloi8f70014a0sfe51bhrej	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Ver Pacientes -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:30:08.035
cmkloi9uo0016a0sfc0qgg03o	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Crear Pacientes -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:30:09.889
cmkloiapb0018a0sfx98mty3g	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Editar Pacientes -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:30:10.991
cmkloibga001aa0sfj0cc3qf0	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Eliminar Pacientes -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:30:11.962
cmkloj7qf001ca0sfa01mc23e	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Crear Usuarios -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:30:53.799
cmkloj8lx001ea0sfd4inog47	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Crear Usuarios -> false	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:30:54.934
cmklokzdr001ga0sfv1cbkhoi	UPDATE_PERMISSION	Role: KINESIOLOGIST, Action: Crear Usuarios -> false	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:32:16.287
cmklol04s001ia0sfgimppp9n	UPDATE_PERMISSION	Role: KINESIOLOGIST, Action: Editar Usuarios -> false	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:32:17.26
cmklol0oc001ka0sfxtfski7b	UPDATE_PERMISSION	Role: KINESIOLOGIST, Action: Eliminar Usuarios -> false	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:32:17.965
cmklol1d5001ma0sf9mojlpiq	UPDATE_PERMISSION	Role: KINESIOLOGIST, Action: Ver Reportes BI -> false	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:32:18.857
cmklol9l7001oa0sfmg7aum6a	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Ver Pacientes -> false	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:32:29.515
cmklolats001qa0sf2k8b7o7o	UPDATE_PERMISSION	Role: KINESIOLOGIST, Action: Ver Pacientes -> false	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:32:31.121
cmklole7t001sa0sf383y6uwb	UPDATE_PERMISSION	Role: KINESIOLOGIST, Action: Ver Pacientes -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:32:35.514
cmkloleza001ua0sfmxckjbqp	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Ver Pacientes -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:32:36.502
cmklolwa6001wa0sflc0ntnqz	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Eliminar Pacientes -> false	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:32:58.926
cmklolxaz001ya0sfy28qlfzq	UPDATE_PERMISSION	Role: RECEPTIONIST, Action: Eliminar Pacientes -> true	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:33:00.251
cmklotdxi002la0sfuh995ah4	BATCH_UPDATE_PERMISSIONS	Updated 22 permissions	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:38:48.39
cmklottd60038a0sfgzmm1wnd	BATCH_UPDATE_PERMISSIONS	Updated 22 permissions	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:39:08.394
cmkloubrh003va0sfbplegvpx	BATCH_UPDATE_PERMISSIONS	Updated 22 permissions	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:39:32.238
cmkloumh8004ia0sfty8huppx	BATCH_UPDATE_PERMISSIONS	Updated 22 permissions	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-19 21:39:46.124
cmklveowe0001cgopm57rpvtk	CREATE_SYSTEM_USER	User created: kine_1768869799360@test.com, Role: KINESIOLOGIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:43:20.079
cmklvgfjm0004cgopnwgf3hu2	CREATE_SYSTEM_USER	User created: valid_user_1768869881035@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:44:41.266
cmklvght30005cgop1ytd9axe	UPDATE_SYSTEM_USER	User updated: valid_user_1768526742717@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:44:44.2
cmklvgnsx0007cgopnz4as5j3	CREATE_SYSTEM_USER	User created: kine_1768869891425@test.com, Role: KINESIOLOGIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:44:51.969
cmklvjowe000acgopcerh817m	CREATE_SYSTEM_USER	User created: valid_user_1768870033143@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:47:13.358
cmklvjrn7000bcgopr4gypf3g	UPDATE_SYSTEM_USER	User updated: valid_user_1768526416966@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:47:16.916
cmklvjurm000dcgopz8qh4gy1	CREATE_SYSTEM_USER	User created: kine_1768870040642@test.com, Role: KINESIOLOGIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:47:20.963
cmklvm1s9000gcgop8psls30s	CREATE_SYSTEM_USER	User created: valid_user_1768870142923@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:49:03.37
cmklvm562000hcgopha1xjt4k	UPDATE_SYSTEM_USER	User updated: kine_1768527111254@test.com, Role: KINESIOLOGIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:49:07.754
cmklvm9gp000kcgopfg8dki9u	CREATE_SYSTEM_USER	User created: kine_1768870153114@test.com, Role: KINESIOLOGIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:49:13.321
cmklvoid7000mcgopc1va87jf	CREATE_SYSTEM_USER	User created: valid_user_1768870257920@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:50:58.171
cmklvols0000ncgop6t57hohx	UPDATE_SYSTEM_USER	User updated: valid_user_1768527228331@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:51:02.592
cmklvujqq00017890cd7ooiak	CREATE_SYSTEM_USER	User created: kine_1768870539091@test.com, Role: KINESIOLOGIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:55:39.89
cmklvwq8j000d7890xgrvg05s	CREATE_SYSTEM_USER	User created: valid_user_1768870641370@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:57:21.619
cmklvwsbv000e7890c4ci22hn	UPDATE_SYSTEM_USER	User updated: kine@test.com, Role: KINESIOLOGIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:57:24.332
cmklvx1si000g7890repxrb5s	CREATE_SYSTEM_USER	User created: kine_1768870655851@test.com, Role: KINESIOLOGIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 00:57:36.594
cmklw0mot000r7890gt72lcuu	CREATE_SYSTEM_USER	User created: valid_user_1768870822649@hospital.cl, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 01:00:23.646
cmklw0qe8000s78904al5nizt	UPDATE_SYSTEM_USER	User updated: recep@test.com, Role: RECEPTIONIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 01:00:28.448
cmklw0w1r000u7890hi0a0utc	CREATE_SYSTEM_USER	User created: kine_1768870834969@test.com, Role: KINESIOLOGIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 01:00:35.775
cmklw6xer001978902sm7q61c	UPDATE_SYSTEM_USER	User updated: kine_1768869799360@test.com, Role: KINESIOLOGIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 01:05:17.475
cmklx0se70001nrmcvp7bzbl1	CREATE_SYSTEM_USER	User created: kine_1768872498195@test.com, Role: KINESIOLOGIST	cmkg60uo5000013oy82gw4zj9	admin@example.com	\N	2026-01-20 01:28:30.655
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."User" (id, email, rut, password, name, role, active, "mustChangePassword", "createdAt", "updatedAt") FROM stdin;
cmklvgfjc0003cgopjoaahrvu	valid_user_1768869881035@hospital.cl	\N	$2b$10$ecQDC0UD20R31QuOWQLzhO/l9HofVw7XBra7ifMuIV2wYMECxnoCC	Valid User Test	RECEPTIONIST	t	t	2026-01-20 00:44:41.257	2026-01-20 00:44:41.257
cmkg75scr004izvod113tdwy3	valid_user_1768526742717@hospital.cl	\N	$2b$10$DJsK/kB2hHM6uoeRKJWjQeljRuo8bzMYDrKSSCnCEEpA1FvrbEmHS	Valid User Test Updated	RECEPTIONIST	t	t	2026-01-16 01:25:42.988	2026-01-20 00:44:44.184
cmklvgnsb0006cgopjuqbdh58	kine_1768869891425@test.com	\N	$2b$10$6vossU7uhBHOLxssQxZ91.jQd5M4S7Dk6izsq.Ncl6bdjPNaQZoaW	Test Kine	KINESIOLOGIST	t	t	2026-01-20 00:44:51.947	2026-01-20 00:44:51.947
cmklvjovw0009cgopmr5pane5	valid_user_1768870033143@hospital.cl	\N	$2b$10$Wjq5xOcE56hVkkijzTZbK.5OWxDl.zGfXw5tasz2J.lAzhXi4e0Ie	Valid User Test	RECEPTIONIST	t	t	2026-01-20 00:47:13.34	2026-01-20 00:47:13.34
cmkg6yt3w003vzvodn1nc777b	valid_user_1768526416966@hospital.cl	\N	$2b$10$BTSkFjkrrgDfbFsnadWeDuq5KNZCQrKCM8.77jYF5k5OGfJtcosVG	Valid User Test Updated Updated	RECEPTIONIST	t	t	2026-01-16 01:20:17.373	2026-01-20 00:47:16.91
cmklvjuri000ccgopzrni46hk	kine_1768870040642@test.com	\N	$2b$10$Z.A3lnuEiWC/i1B.YvsxJ.gDz7MOIwYQMKsuBDpgfYDySAF43j5US	Test Kine	KINESIOLOGIST	t	t	2026-01-20 00:47:20.958	2026-01-20 00:47:20.958
cmklvm1q1000fcgopa2encr1k	valid_user_1768870142923@hospital.cl	\N	$2b$10$CUUFcFoN1CdGgourXL5wzOHRlhnPuI3EiRnjOOE43cmt4i87TcmvG	Valid User Test	RECEPTIONIST	t	t	2026-01-20 00:49:03.289	2026-01-20 00:49:03.289
cmkg7dtaf004lzvod8uomwrn4	kine_1768527111254@test.com	\N	$2b$10$Di6yyeQ/CyvqWOGpVnYH5uCOjC9O7CY.FTUK1vPGI5pfujq6nYvvC	Test Kine Updated	KINESIOLOGIST	t	t	2026-01-16 01:31:57.448	2026-01-20 00:49:07.748
cmklvm9gl000jcgopt8z2cu76	kine_1768870153114@test.com	\N	$2b$10$PLqPJof9bTvX8CLG8bJohug/f32rBNVuzIVyHm.JQ.ih0BbOPQaBm	Test Kine	KINESIOLOGIST	t	t	2026-01-20 00:49:13.318	2026-01-20 00:49:13.318
cmklvoid0000lcgopymo3uxv6	valid_user_1768870257920@hospital.cl	\N	$2b$10$PKmw9L0.ApIjK90IBSvkK.3b2dyyY0281o7qwOWb9f0K39uGcqhNe	Valid User Test	RECEPTIONIST	t	t	2026-01-20 00:50:58.165	2026-01-20 00:50:58.165
cmkg7g88t004wzvodtrzayecn	valid_user_1768527228331@hospital.cl	\N	$2b$10$s1/CWWE/9QXtp7bDOq7zb.ECWnKCBNW8VyJaYMLwbBLe74L3PF8xq	Valid User Test Updated	RECEPTIONIST	t	t	2026-01-16 01:33:50.142	2026-01-20 00:51:02.585
cmklvujph00007890p04pcw9q	kine_1768870539091@test.com	\N	$2b$10$oaJtUSPocn10Q7Qn1FW17O7AHDBt5rJJb26DspmoqdBVTQqeIgpt2	Test Kine	KINESIOLOGIST	t	t	2026-01-20 00:55:39.843	2026-01-20 00:55:39.843
cmklvwq81000c7890urundy28	valid_user_1768870641370@hospital.cl	\N	$2b$10$oMyvHdc3Xp7ZoZOMRwuDbeDdpHqtnX9UziXHCcISMhwRgeuQ05.4O	Valid User Test	RECEPTIONIST	t	t	2026-01-20 00:57:21.601	2026-01-20 00:57:21.601
cmklovyuc000012hhphu6osv7	kine@test.com	\N	$2b$10$fZaKXb76BvCxctx2gVA33.tDDs.143n3drdQ8MYX2L2wz/NINkuFW	Kinesiólogo Test Updated	KINESIOLOGIST	t	f	2026-01-19 21:40:48.803	2026-01-20 00:57:24.323
cmklvx1pe000f78904ujcvgvc	kine_1768870655851@test.com	\N	$2b$10$wWYhA0ph0F1k6CPqFg36penKnCdPaYFv/1/xZN7nvvrhwxStAeIfm	Test Kine	KINESIOLOGIST	t	t	2026-01-20 00:57:36.483	2026-01-20 00:57:36.483
cmklw0moc000q7890tjd7mjd3	valid_user_1768870822649@hospital.cl	\N	$2b$10$10Vqf1Ob.7u/9ZUo8vufqu8lQ/CJnzY7QPlGvGOs3T5VkqYbMhoHy	Valid User Test	RECEPTIONIST	t	t	2026-01-20 01:00:23.628	2026-01-20 01:00:23.628
cmklovyyv000112hhblhbv9em	recep@test.com	\N	$2b$10$Af7pl8BqmwWGQpUbKP7Zb.5bbX7pWZp34JNQDnhDYB.LWvs.nxHCm	Recepcionista Test Updated	RECEPTIONIST	t	f	2026-01-19 21:40:48.968	2026-01-20 01:00:28.44
cmklw0w02000t7890i4fm0m04	kine_1768870834969@test.com	\N	$2b$10$MiowtGh8l8L0KNAvLVpdy.F.ifQwiB.f5NRtGwJZmoZECrSAIK5nW	Test Kine	KINESIOLOGIST	t	t	2026-01-20 01:00:35.714	2026-01-20 01:00:35.714
cmkg60uo5000013oy82gw4zj9	admin@example.com	1-9	$2b$10$gbPjvskHQffCCkbUJ5r4YuiSGybr6C10.LuVJsTb4PG3OakvEUWsW	Admin User Updated Updated	ADMIN	t	f	2026-01-16 00:53:53.093	2026-01-20 01:01:34.229
cmklveosp0000cgoppts1tnem	kine_1768869799360@test.com	\N	$2b$10$LphBE5BXf0q4RAqwAr7zAeyEwUf28jB4H28latZDL315hKE788Rbq	Test Kine Updated	KINESIOLOGIST	t	t	2026-01-20 00:43:19.945	2026-01-20 01:05:17.326
cmklx0rvq0000nrmcll3sodai	kine_1768872498195@test.com	\N	$2b$10$2k9fD49l/Z6ZXSFslGpT.ulR0q14ppmmGIrPzmLDfsRWnBcpiHe9e	Test Kine	KINESIOLOGIST	t	t	2026-01-20 01:28:29.95	2026-01-20 01:28:29.95
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
c3bfaac2-5a10-4145-9c26-33d471b3c7a9	b05f672e780a8f1c694f8b33be4767bfda63d2d59e6b2bd05fc31917ff615406	2026-01-16 02:30:41.081272+00	20260105175559_split_user_patient_tables		\N	2026-01-16 02:30:41.081272+00	0
b15422cc-817e-4e3b-97ff-36f4c10bb4b8	b70cbe5e850b0af2600d4f2919e98cc2382ee50a5011139e6256180a8be493da	2026-01-16 02:30:41.990446+00	20260107031229_add_vector_support		\N	2026-01-16 02:30:41.990446+00	0
1560e5fe-c132-41b4-a506-10885c6d1a78	58bf7f846eb0fccf1fb155bc45c04d67010cc2b98d1d7f413d1c703705909649	2026-01-16 02:30:42.932145+00	20260107165913_add_region_to_patient		\N	2026-01-16 02:30:42.932145+00	0
5d3f4f21-d68c-41a8-8ff0-724ee22f0197	0e520116d73e6ad37cec9cd5092e8f49457d2e053361134199ebc91ad4d90d6c	2026-01-16 02:30:45.547558+00	20260114004900_add_cota_field_fixed		\N	2026-01-16 02:30:45.547558+00	0
0dcff5ef-2ceb-4e88-adb3-8c360e537a23	c361201b160b25d3205b554495373af39ced9058adb62618fb1c4c7aa7aa9c60	\N	20251231235059_init_postgres_local	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20251231235059_init_postgres_local\n\nDatabase error code: 42P07\n\nDatabase error:\nERROR: relation "User" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P07), message: "relation \\"User\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("heap.c"), line: Some(1150), routine: Some("heap_create_with_catalog") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20251231235059_init_postgres_local"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="20251231235059_init_postgres_local"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226	2026-01-19 21:23:04.573274+00	2026-01-19 21:22:18.158207+00	0
7688d9a5-f09e-47aa-be45-10d45e6f4409	c361201b160b25d3205b554495373af39ced9058adb62618fb1c4c7aa7aa9c60	2026-01-19 21:23:04.57577+00	20251231235059_init_postgres_local		\N	2026-01-19 21:23:04.57577+00	0
31f3f7e8-cb8e-4023-8064-1a41c8ed5d3d	04ffe38fb23630850cbdbc73743d5f0e06aea80f303d1dba01a3e18146d5cdda	\N	20260104023925_add_must_change_password	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260104023925_add_must_change_password\n\nDatabase error code: 42701\n\nDatabase error:\nERROR: column "mustChangePassword" of relation "User" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42701), message: "column \\"mustChangePassword\\" of relation \\"User\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("tablecmds.c"), line: Some(7279), routine: Some("check_for_column_name_collision") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260104023925_add_must_change_password"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="20260104023925_add_must_change_password"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226	2026-01-19 21:37:01.275143+00	2026-01-19 21:35:31.597282+00	0
2ec2e838-081f-48d5-8a34-3428ae4a7641	d2f861858a9fa959c48f514dffe38e3d693a1a2daa4924e901e1f49731dff80b	\N	20260104013743_add_logs_and_permissions	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260104013743_add_logs_and_permissions\n\nDatabase error code: 42P07\n\nDatabase error:\nERROR: relation "SystemLog" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P07), message: "relation \\"SystemLog\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("heap.c"), line: Some(1150), routine: Some("heap_create_with_catalog") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260104013743_add_logs_and_permissions"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="20260104013743_add_logs_and_permissions"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226	2026-01-19 21:23:39.267344+00	2026-01-19 21:23:12.206459+00	0
e1bbb11a-34c7-42d5-837f-45802cc39441	d2f861858a9fa959c48f514dffe38e3d693a1a2daa4924e901e1f49731dff80b	2026-01-19 21:23:39.27026+00	20260104013743_add_logs_and_permissions		\N	2026-01-19 21:23:39.27026+00	0
f30b0510-5284-4fc1-9875-57c64141d785	04ffe38fb23630850cbdbc73743d5f0e06aea80f303d1dba01a3e18146d5cdda	2026-01-19 21:37:01.279713+00	20260104023925_add_must_change_password		\N	2026-01-19 21:37:01.279713+00	0
d08ea31b-b1bb-4aec-9cc4-ce104d547888	5fe5dd62628c1c01cf451445ce76ae00ece9fba13fda728527d60f5b267d62e1	\N	20260105134211_add_rut_to_user_remove_from_patient	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260105134211_add_rut_to_user_remove_from_patient\n\nDatabase error code: 42701\n\nDatabase error:\nERROR: column "rut" of relation "User" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42701), message: "column \\"rut\\" of relation \\"User\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("tablecmds.c"), line: Some(7279), routine: Some("check_for_column_name_collision") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260105134211_add_rut_to_user_remove_from_patient"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="20260105134211_add_rut_to_user_remove_from_patient"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226	2026-01-19 21:48:03.851892+00	2026-01-19 21:47:40.689966+00	0
792435d7-24ea-4c10-a2ac-6532a37c054c	5fe5dd62628c1c01cf451445ce76ae00ece9fba13fda728527d60f5b267d62e1	2026-01-19 21:48:03.881803+00	20260105134211_add_rut_to_user_remove_from_patient		\N	2026-01-19 21:48:03.881803+00	0
02153f2c-e3db-4456-81b5-6db01327d9ad	1ab0cb2e9a856400847843f54608d58fc94f7ab683e835e6e4f35e7c3df0e3b3	\N	20260116000000_add_reviewed_field	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260116000000_add_reviewed_field\n\nDatabase error code: 42701\n\nDatabase error:\nERROR: column "reviewed" of relation "MedicalExam" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42701), message: "column \\"reviewed\\" of relation \\"MedicalExam\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("tablecmds.c"), line: Some(7279), routine: Some("check_for_column_name_collision") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260116000000_add_reviewed_field"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="20260116000000_add_reviewed_field"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226	2026-01-19 21:50:33.745937+00	2026-01-19 21:50:15.468852+00	0
5c62e237-bcc5-45fe-954e-917bc8878c40	1ab0cb2e9a856400847843f54608d58fc94f7ab683e835e6e4f35e7c3df0e3b3	2026-01-19 21:50:33.751818+00	20260116000000_add_reviewed_field		\N	2026-01-19 21:50:33.751818+00	0
\.


--
-- Name: Appointment Appointment_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_pkey" PRIMARY KEY (id);


--
-- Name: MedicalExam MedicalExam_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MedicalExam"
    ADD CONSTRAINT "MedicalExam_pkey" PRIMARY KEY (id);


--
-- Name: MedicalKnowledge MedicalKnowledge_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MedicalKnowledge"
    ADD CONSTRAINT "MedicalKnowledge_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: Patient Patient_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Patient"
    ADD CONSTRAINT "Patient_pkey" PRIMARY KEY (id);


--
-- Name: PulmonaryFunctionTest PulmonaryFunctionTest_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PulmonaryFunctionTest"
    ADD CONSTRAINT "PulmonaryFunctionTest_pkey" PRIMARY KEY (id);


--
-- Name: RolePermission RolePermission_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_pkey" PRIMARY KEY (id);


--
-- Name: SystemLog SystemLog_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SystemLog"
    ADD CONSTRAINT "SystemLog_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Notification_read_createdAt_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "Notification_read_createdAt_idx" ON public."Notification" USING btree (read, "createdAt");


--
-- Name: PasswordResetToken_email_idx; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PasswordResetToken_email_idx" ON public."PasswordResetToken" USING btree (email);


--
-- Name: PasswordResetToken_token_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "PasswordResetToken_token_key" ON public."PasswordResetToken" USING btree (token);


--
-- Name: Patient_email_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Patient_email_key" ON public."Patient" USING btree (email);


--
-- Name: Patient_rut_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Patient_rut_key" ON public."Patient" USING btree (rut);


--
-- Name: RolePermission_role_action_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "RolePermission_role_action_key" ON public."RolePermission" USING btree (role, action);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_rut_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "User_rut_key" ON public."User" USING btree (rut);


--
-- Name: Appointment Appointment_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Appointment"
    ADD CONSTRAINT "Appointment_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MedicalExam MedicalExam_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MedicalExam"
    ADD CONSTRAINT "MedicalExam_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Notification Notification_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PulmonaryFunctionTest PulmonaryFunctionTest_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PulmonaryFunctionTest"
    ADD CONSTRAINT "PulmonaryFunctionTest_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: admin
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict MZVRvgNia84EXPGIwL8lV4RvypAh5DOA3MVveHDzfp5RffIXrntRg2KHuZO3Bf7

